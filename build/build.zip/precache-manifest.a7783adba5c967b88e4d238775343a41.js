self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6622daf469343797aa4fd948310e298d",
    "url": "./index.html"
  },
  {
    "revision": "790ccb9ec229c2ac3301",
    "url": "./static/css/2.41fc952c.chunk.css"
  },
  {
    "revision": "cac0ce941ba3e9e4c728",
    "url": "./static/css/main.3b685b52.chunk.css"
  },
  {
    "revision": "790ccb9ec229c2ac3301",
    "url": "./static/js/2.a448fabb.chunk.js"
  },
  {
    "revision": "3453b8997016469371284a28c0e873e2",
    "url": "./static/js/2.a448fabb.chunk.js.LICENSE.txt"
  },
  {
    "revision": "cac0ce941ba3e9e4c728",
    "url": "./static/js/main.bc890ec5.chunk.js"
  },
  {
    "revision": "596db6d2290197e71c87",
    "url": "./static/js/runtime-main.cf705ba3.js"
  },
  {
    "revision": "ec198c88d5580cea3beae7d4b576112e",
    "url": "./static/media/US-flag.ec198c88.jpg"
  },
  {
    "revision": "4747803c4fcca27970cf0a2e1edb2757",
    "url": "./static/media/naruto-sasuke.4747803c.jpg"
  },
  {
    "revision": "f76bfc19628c957de8be19ad09d23f88",
    "url": "./static/media/photoProfil.f76bfc19.jpg"
  }
]);